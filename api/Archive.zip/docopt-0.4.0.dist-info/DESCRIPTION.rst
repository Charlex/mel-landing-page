`docopt` lives on `GitHub <http://github.com/halst/docopt/>`_.


